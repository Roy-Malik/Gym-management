
import React from 'react';
import { Routes, Route, Outlet } from 'react-router-dom';
import Layout from './components/Layout';
import AdminDashboardPage from './pages/AdminDashboardPage';
import UsersManagementPage from './pages/UsersManagementPage';
import PlansManagementPage from './pages/PlansManagementPage';
import PaymentsPage from './pages/PaymentsPage';
import SchedulePage from './pages/SchedulePage';
import AnnouncementsPage from './pages/AnnouncementsPage';

const App: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<AdminDashboardPage />} />
        <Route path="members" element={<UsersManagementPage type="Members" />} />
        <Route path="trainers" element={<UsersManagementPage type="Trainers" />} />
        <Route path="workout-plans" element={<PlansManagementPage type="Workout" />} />
        <Route path="diet-plans" element={<PlansManagementPage type="Diet" />} />
        <Route path="schedule" element={<SchedulePage />} />
        <Route path="payments" element={<PaymentsPage />} />
        <Route path="announcements" element={<AnnouncementsPage />} />
        <Route path="*" element={<div className="p-8 text-center">Page Not Found</div>} />
      </Route>
    </Routes>
  );
};

export default App;
