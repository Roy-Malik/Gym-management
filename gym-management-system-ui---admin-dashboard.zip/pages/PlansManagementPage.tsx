
import React from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { PlusIcon, SearchIcon, ClipboardListIcon } from '../components/icons'; // Assuming ClipboardListIcon exists

interface PlansManagementPageProps {
  type: 'Workout' | 'Diet';
}

const PlansManagementPage: React.FC<PlansManagementPageProps> = ({ type }) => {
  const mockPlans = [
    { id: 1, name: `${type} Plan Alpha`, description: `Comprehensive ${type.toLowerCase()} plan for beginners.`, createdDate: '2023-05-10', assignedTo: 5 },
    { id: 2, name: `${type} Plan Beta`, description: `Advanced ${type.toLowerCase()} regimen for athletes.`, createdDate: '2023-06-15', assignedTo: 3 },
    { id: 3, name: `${type} Plan Gamma`, description: `Weight loss focused ${type.toLowerCase()} plan.`, createdDate: '2023-07-20', assignedTo: 8 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-3xl font-serif font-bold text-text-primary">{type} Plans Management</h2>
        <Button variant="primary" size="md" leftIcon={<PlusIcon className="w-5 h-5" />}>
          Create New {type} Plan
        </Button>
      </div>

      <Card>
        <div className="mb-4 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-auto">
                <input 
                type="text" 
                placeholder={`Search ${type.toLowerCase()} plans...`}
                className="w-full sm:w-64 bg-background text-text-primary border border-border rounded-lg pl-10 pr-4 py-2 focus:ring-brand-primary focus:border-brand-primary"
                />
                <SearchIcon className="w-5 h-5 text-text-muted absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockPlans.map(plan => (
                <Card key={plan.id} className="hover:shadow-soft-xl transition-shadow duration-300">
                    <div className="flex items-center mb-3">
                        <ClipboardListIcon className="w-8 h-8 text-brand-primary mr-3" />
                        <h3 className="text-lg font-semibold text-text-primary">{plan.name}</h3>
                    </div>
                    <p className="text-sm text-text-secondary mb-2 h-16 overflow-hidden text-ellipsis">{plan.description}</p>
                    <p className="text-xs text-text-muted">Created: {plan.createdDate}</p>
                    <p className="text-xs text-text-muted">Assigned to: {plan.assignedTo} members</p>
                    <div className="mt-4 flex justify-end space-x-2">
                        <Button variant="ghost" size="sm">View</Button>
                        <Button variant="outline" size="sm">Edit</Button>
                    </div>
                </Card>
            ))}
        </div>
         {/* Pagination could be added here */}
         <div className="mt-6 flex justify-center">
            <nav className="inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <Button variant="outline" size="sm" className="rounded-l-md">Previous</Button>
                <Button variant="outline" size="sm" className="rounded-r-md">Next</Button>
            </nav>
        </div>
      </Card>
    </div>
  );
};

export default PlansManagementPage;
