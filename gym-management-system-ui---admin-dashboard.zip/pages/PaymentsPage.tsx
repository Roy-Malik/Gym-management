
import React from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { PlusIcon, SearchIcon, CreditCardIcon } from '../components/icons';

const PaymentsPage: React.FC = () => {
  const mockPayments = [
    { id: 'INV001', memberName: 'Alice Johnson', amount: 75, status: 'Paid', date: '2024-07-15', dueDate: '2024-07-01' },
    { id: 'INV002', memberName: 'Bob Williams', amount: 50, status: 'Pending', date: '2024-07-20', dueDate: '2024-07-10' },
    { id: 'INV003', memberName: 'Charlie Brown', amount: 100, status: 'Overdue', date: '2024-06-25', dueDate: '2024-06-01' },
    { id: 'INV004', memberName: 'Diana Prince', amount: 75, status: 'Paid', date: '2024-07-01', dueDate: '2024-07-01' },
  ];

  const getStatusClass = (status: string) => {
    if (status === 'Paid') return 'bg-green-100 text-green-800';
    if (status === 'Pending') return 'bg-yellow-100 text-yellow-800';
    if (status === 'Overdue') return 'bg-red-100 text-red-800';
    return 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-3xl font-serif font-bold text-text-primary">Payments</h2>
        <Button variant="primary" size="md" leftIcon={<PlusIcon className="w-5 h-5" />}>
          Record New Payment
        </Button>
      </div>

      <Card>
        <div className="mb-4 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-auto">
                <input 
                type="text" 
                placeholder="Search payments (ID, Member)..."
                className="w-full sm:w-72 bg-background text-text-primary border border-border rounded-lg pl-10 pr-4 py-2 focus:ring-brand-primary focus:border-brand-primary"
                />
                <SearchIcon className="w-5 h-5 text-text-muted absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
            {/* Filters for status, date range etc. */}
            <div className="flex space-x-2">
                <Button variant="outline" size="sm">All</Button>
                <Button variant="ghost" size="sm">Paid</Button>
                <Button variant="ghost" size="sm">Pending</Button>
                <Button variant="ghost" size="sm">Overdue</Button>
            </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-border">
            <thead className="bg-background-muted">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Invoice ID</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Member</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Amount</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Payment Date</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Due Date</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-text-muted uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-background-surface divide-y divide-border">
              {mockPayments.map((payment) => (
                <tr key={payment.id} className="hover:bg-background-muted/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-brand-primary hover:underline cursor-pointer">{payment.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">{payment.memberName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">${payment.amount.toFixed(2)}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClass(payment.status)}`}>
                      {payment.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{payment.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{payment.dueDate}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <Button variant="ghost" size="sm" leftIcon={<CreditCardIcon className="w-4 h-4"/>} className="mr-2">
                        {payment.status !== 'Paid' ? 'Mark Paid' : 'View'}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
         {/* Pagination */}
         <div className="mt-6 flex justify-end">
            <nav className="inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <Button variant="outline" size="sm" className="rounded-l-md">Previous</Button>
                <Button variant="outline" size="sm" className="rounded-r-md">Next</Button>
            </nav>
        </div>
      </Card>
    </div>
  );
};

export default PaymentsPage;
