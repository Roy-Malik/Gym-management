
import React from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { PlusIcon, BellIcon as AnnouncementBellIcon, SearchIcon } from '../components/icons'; // Ensure BellIcon is aliased or specific

interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  audience: 'All' | 'Members' | 'Trainers';
}

const mockAnnouncements: Announcement[] = [
  { id: '1', title: 'Gym Reopening Update', content: 'The gym will reopen on Monday with new safety guidelines. Please check your email for details.', date: '2024-07-10', audience: 'All' },
  { id: '2', title: 'New Yoga Class Schedule', content: 'Exciting news! We\'ve added more Yoga classes. See the updated schedule on the app.', date: '2024-07-05', audience: 'Members' },
  { id: '3', title: 'Trainer Meeting Reminder', content: 'A mandatory meeting for all trainers will be held this Friday at 2 PM in the staff room.', date: '2024-07-01', audience: 'Trainers' },
];

const AnnouncementsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-3xl font-serif font-bold text-text-primary">Announcements</h2>
        <Button variant="primary" size="md" leftIcon={<PlusIcon className="w-5 h-5" />}>
          Create New Announcement
        </Button>
      </div>

      <Card>
        <div className="mb-4 flex flex-col sm:flex-row justify-between items-center gap-4">
             <div className="relative w-full sm:w-auto">
                <input 
                type="text" 
                placeholder="Search announcements..."
                className="w-full sm:w-64 bg-background text-text-primary border border-border rounded-lg pl-10 pr-4 py-2 focus:ring-brand-primary focus:border-brand-primary"
                />
                <SearchIcon className="w-5 h-5 text-text-muted absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
            {/* Filters for audience, date range etc. */}
        </div>

        <div className="space-y-6">
          {mockAnnouncements.map((announcement) => (
            <Card key={announcement.id} className="bg-background hover:shadow-soft-xl transition-shadow duration-200">
                <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 mt-1">
                        <AnnouncementBellIcon className="w-6 h-6 text-brand-primary" />
                    </div>
                    <div>
                        <div className="flex flex-col sm:flex-row justify-between items-baseline">
                            <h3 className="text-lg font-semibold text-text-primary">{announcement.title}</h3>
                            <span className="text-xs text-text-muted mt-1 sm:mt-0">{announcement.date} - For: {announcement.audience}</span>
                        </div>
                        <p className="mt-1 text-sm text-text-secondary">{announcement.content}</p>
                        <div className="mt-3 flex space-x-2">
                            <Button variant="ghost" size="sm">Edit</Button>
                            <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700 hover:bg-red-500/10">Delete</Button>
                        </div>
                    </div>
                </div>
            </Card>
          ))}
        </div>
        {mockAnnouncements.length === 0 && (
            <p className="text-center text-text-muted py-8">No announcements found.</p>
        )}
         {/* Pagination */}
         <div className="mt-6 flex justify-center">
            <nav className="inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <Button variant="outline" size="sm" className="rounded-l-md">Previous</Button>
                <Button variant="outline" size="sm" className="rounded-r-md">Next</Button>
            </nav>
        </div>
      </Card>
    </div>
  );
};

export default AnnouncementsPage;
