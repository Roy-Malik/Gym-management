
import React, { useState, useEffect } from 'react';
import DashboardCard from '../components/DashboardCard';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { UsersIcon, DollarSignIcon, BarChartIcon, CreditCardIcon, PlusIcon, ClipboardListIcon, BellIcon } from '../components/icons';
import { RevenueData, DashboardStat } from '../types';
import Tooltip from '../components/ui/Tooltip';

// Mock Recharts components or a placeholder
const ResponsiveContainer: React.FC<{ children: React.ReactNode; width?: string | number; height?: string | number }> = ({ children, width = "100%", height = 300 }) => (
  <div style={{ width, height }}>{children}</div>
);
const BarChart: React.FC<{ data: any; children: React.ReactNode, margin?: object }> = ({ data, children }) => (
  <div className="w-full h-full bg-background-muted rounded-lg p-4 flex items-center justify-center text-text-muted">
    <BarChartIcon className="w-16 h-16 text-text-muted/50 mr-2" />
    Bar Chart Placeholder (Data: {data.length} items)
    {/* Children like XAxis, YAxis, Tooltip, Bar would be here */}
  </div>
);
const XAxis: React.FC<{ dataKey: string }> = () => null; // Mock
const YAxis: React.FC = () => null; // Mock
const RechartsTooltip: React.FC = () => null; // Mock
const Bar: React.FC<{ dataKey: string; fill: string; radius?: [number, number, number, number]}> = () => null; // Mock
const Legend: React.FC = () => null; // Mock

const mockRevenueData: RevenueData[] = [
  { month: 'Jan', revenue: 4000 },
  { month: 'Feb', revenue: 3000 },
  { month: 'Mar', revenue: 5000 },
  { month: 'Apr', revenue: 4500 },
  { month: 'May', revenue: 6000 },
  { month: 'Jun', revenue: 5500 },
];

const AdminDashboardPage: React.FC = () => {
  const [loadingStats, setLoadingStats] = useState(true);
  const [stats, setStats] = useState<DashboardStat[]>([]);

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setStats([
        { title: "Total Members", value: 125, icon: UsersIcon, trend: "+5 this month" },
        { title: "Active Trainers", value: 15, icon: UsersIcon, trend: "+1 this month" },
        { title: "Monthly Revenue", value: 5650, icon: DollarSignIcon, trend: "+12%" },
        { title: "Pending Payments", value: 8, icon: CreditCardIcon, trend: "-2 from last week" },
      ]);
      setLoadingStats(false);
    }, 1500);
  }, []);


  return (
    <div className="space-y-6 lg:space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-3xl font-serif font-bold text-text-primary">Admin Dashboard</h2>
        <Tooltip text="Add New Member, Trainer, or Plan">
            <Button variant="primary" size="md" leftIcon={<PlusIcon className="w-5 h-5"/>}>
                Quick Add
            </Button>
        </Tooltip>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {loadingStats && Array(4).fill(0).map((_, index) => (
          <DashboardCard key={index} title="" value={0} icon={() => null} loading={true} />
        ))}
        {!loadingStats && stats.map((stat) => (
          <DashboardCard key={stat.title} {...stat} />
        ))}
      </div>

      {/* Revenue Chart and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
        <Card className="lg:col-span-2" title="Revenue Overview" actions={
          <select className="bg-background-surface border border-border text-text-secondary text-sm rounded-md p-2 focus:ring-brand-primary focus:border-brand-primary">
            <option>Last 6 Months</option>
            <option>Last 12 Months</option>
            <option>This Year</option>
          </select>
        }>
          <ResponsiveContainer height={350}>
            <BarChart data={mockRevenueData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
              <XAxis dataKey="month" />
              <YAxis />
              <RechartsTooltip />
              <Legend />
              <Bar dataKey="revenue" fill="#B08D57" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card title="Recent Activity">
          <ul className="space-y-4 max-h-[300px] overflow-y-auto">
            {[
              { user: "Alice Smith", action: "joined as a new member.", time: "2m ago" },
              { user: "Trainer Bob", action: "updated a workout plan.", time: "1h ago" },
              { user: "Payment Received", action: "from John Doe ($75).", time: "3h ago" },
              { user: "Carol White", action: "booked a session.", time: "5h ago" },
              { user: "New Announcement", action: "posted: 'Holiday Hours'.", time: "1d ago" },
            ].map((activity, index) => (
              <li key={index} className="flex items-start space-x-3">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-brand-primary/20 flex items-center justify-center text-brand-primary">
                  <UsersIcon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm text-text-primary">
                    <span className="font-medium">{activity.user}</span> {activity.action}
                  </p>
                  <p className="text-xs text-text-muted">{activity.time}</p>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      </div>

       {/* Quick Actions Section */}
       <Card title="Quick Actions">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <Button variant="outline" size="md" leftIcon={<PlusIcon className="w-4 h-4"/>}>Add Member</Button>
                <Button variant="outline" size="md" leftIcon={<PlusIcon className="w-4 h-4"/>}>Add Trainer</Button>
                <Button variant="outline" size="md" leftIcon={<ClipboardListIcon className="w-4 h-4"/>}>New Plan</Button>
                <Button variant="outline" size="md" leftIcon={<BellIcon className="w-4 h-4"/>}>Send Announcement</Button>
            </div>
        </Card>
    </div>
  );
};

export default AdminDashboardPage;
