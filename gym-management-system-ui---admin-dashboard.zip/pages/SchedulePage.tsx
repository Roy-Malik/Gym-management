
import React, { useState } from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { PlusIcon, CalendarDaysIcon } from '../components/icons'; // Ensure CalendarDaysIcon is correct

// Mock data - in a real app, this would come from state/API
const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const timeSlots = ['9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM'];

interface Event {
  id: string;
  day: string;
  time: string;
  title: string;
  trainer: string;
  type: 'class' | 'session';
}

const mockEvents: Event[] = [
  { id: '1', day: 'Mon', time: '10:00 AM', title: 'Yoga Basics', trainer: 'Sarah K.', type: 'class' },
  { id: '2', day: 'Wed', time: '2:00 PM', title: 'PT with John Doe', trainer: 'Mike R.', type: 'session' },
  { id: '3', day: 'Fri', time: '5:00 PM', title: 'HIIT Blast', trainer: 'David L.', type: 'class' },
  { id: '4', day: 'Tue', time: '9:00 AM', title: 'PT with Alice Smith', trainer: 'Sarah K.', type: 'session' },
];

const SchedulePage: React.FC = () => {
  const [viewMode, setViewMode] = useState<'week' | 'month'>('week'); // Simple toggle for now

  const renderEvent = (event: Event) => (
    <div 
      key={event.id} 
      className={`p-2 rounded-lg text-xs ${event.type === 'class' ? 'bg-brand-primary/80 text-white' : 'bg-sky-500/80 text-white'} cursor-pointer hover:opacity-80 transition-opacity`}
      title={`${event.title} with ${event.trainer}`}
    >
      <p className="font-semibold truncate">{event.title}</p>
      <p className="truncate">{event.trainer}</p>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-3xl font-serif font-bold text-text-primary">Schedule Management</h2>
        <div className="flex items-center space-x-2">
            <div className="flex space-x-1 bg-background-muted p-1 rounded-lg">
                <Button variant={viewMode === 'week' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('week')}>Week</Button>
                <Button variant={viewMode === 'month' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('month')} disabled>Month</Button> 
            </div>
            <Button variant="primary" size="md" leftIcon={<PlusIcon className="w-5 h-5" />}>
                Add Event
            </Button>
        </div>
      </div>

      <Card>
        {viewMode === 'week' && (
            <div className="overflow-x-auto">
                <div className="grid grid-cols-8 min-w-[800px]"> {/* Header + 7 days */}
                    {/* Time column header */}
                    <div className="p-2 border-r border-b border-border text-text-muted font-medium text-sm">Time</div>
                    {/* Day headers */}
                    {daysOfWeek.map(day => (
                        <div key={day} className="p-2 border-r border-b border-border text-center text-text-muted font-medium text-sm">{day}</div>
                    ))}

                    {/* Time slots and events */}
                    {timeSlots.map(time => (
                        <React.Fragment key={time}>
                            <div className="p-2 border-r border-b border-border text-text-secondary text-xs h-20 flex items-center justify-center">{time}</div>
                            {daysOfWeek.map(day => (
                                <div key={`${day}-${time}`} className="p-1 border-r border-b border-border h-20 space-y-1 overflow-y-auto">
                                    {mockEvents.filter(e => e.day === day && e.time === time).map(renderEvent)}
                                </div>
                            ))}
                        </React.Fragment>
                    ))}
                </div>
            </div>
        )}
        {viewMode === 'month' && (
            <div className="p-6 text-center text-text-muted">
                <CalendarDaysIcon className="w-16 h-16 mx-auto mb-4 text-brand-primary/50" />
                Month view is not implemented yet.
            </div>
        )}
      </Card>
    </div>
  );
};

export default SchedulePage;
