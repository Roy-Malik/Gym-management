
import React from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { PlusIcon, SearchIcon } from '../components/icons';

interface UsersManagementPageProps {
  type: 'Members' | 'Trainers';
}

const UsersManagementPage: React.FC<UsersManagementPageProps> = ({ type }) => {
  const mockUsers = [
    { id: 1, name: type === 'Members' ? 'Alice Johnson' : 'Trainer Mike', email: type === 'Members' ? 'alice@example.com' : 'mike@example.com', status: 'Active', joinDate: '2023-01-15' },
    { id: 2, name: type === 'Members' ? 'Bob Williams' : 'Trainer Sarah', email: type === 'Members' ? 'bob@example.com' : 'sarah@example.com', status: 'Inactive', joinDate: '2023-03-22' },
    { id: 3, name: type === 'Members' ? 'Charlie Brown' : 'Trainer David', email: type === 'Members' ? 'charlie@example.com' : 'david@example.com', status: 'Active', joinDate: '2022-11-05' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-3xl font-serif font-bold text-text-primary">{type} Management</h2>
        <Button variant="primary" size="md" leftIcon={<PlusIcon className="w-5 h-5" />}>
          Add New {type === 'Members' ? 'Member' : 'Trainer'}
        </Button>
      </div>

      <Card>
        <div className="mb-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="relative w-full sm:w-auto">
            <input 
              type="text" 
              placeholder={`Search ${type.toLowerCase()}...`}
              className="w-full sm:w-64 bg-background text-text-primary border border-border rounded-lg pl-10 pr-4 py-2 focus:ring-brand-primary focus:border-brand-primary"
            />
            <SearchIcon className="w-5 h-5 text-text-muted absolute left-3 top-1/2 -translate-y-1/2" />
          </div>
          {/* Add filters here if needed */}
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-border">
            <thead className="bg-background-muted">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Email</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-muted uppercase tracking-wider">Join Date</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-text-muted uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-background-surface divide-y divide-border">
              {mockUsers.map((user) => (
                <tr key={user.id} className="hover:bg-background-muted/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-text-primary">{user.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{user.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{user.joinDate}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <Button variant="ghost" size="sm" className="mr-2">Edit</Button>
                    <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700 hover:bg-red-500/10">Delete</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Pagination could be added here */}
         <div className="mt-6 flex justify-end">
            <nav className="inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <Button variant="outline" size="sm" className="rounded-l-md">Previous</Button>
                <Button variant="outline" size="sm" className="rounded-r-md">Next</Button>
            </nav>
        </div>
      </Card>
    </div>
  );
};

export default UsersManagementPage;
