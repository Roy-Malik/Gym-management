
import React from 'react';

export const SettingsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-1.003 1.11-.962a8.948 8.948 0 007.141 5.003c.483.03.92.429.962 1.003.015.221.015.442 0 .663a1.003 1.003 0 01-.962 1.003 8.947 8.947 0 00-7.141 5.003c-.09.542-.56 1.003-1.11.962a8.953 8.953 0 00-5.003-7.14c-.483-.03-.92-.429-.962-1.003a8.95 8.95 0 000-.663A1.003 1.003 0 014.59 8.95a8.953 8.953 0 005.004-5.01zM12 15.75a3.75 3.75 0 100-7.5 3.75 3.75 0 000 7.5z" />
  </svg>
);
