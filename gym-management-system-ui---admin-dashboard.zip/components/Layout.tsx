
import React, { useState, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import Navbar from './Navbar';
import { ADMIN_NAV_ITEMS, APP_NAME, USER_MENU_ITEMS } from '../constants';
import { UserProfile } from '../types';

const Layout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const location = useLocation(); // To close sidebar on mobile nav
  
  const [userProfile] = useState<UserProfile>({ // Mock user profile
    name: "Admin User",
    role: "Administrator",
    avatarUrl: "https://picsum.photos/seed/admin/100/100"
  });

  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (!mobile) { // If resizing to desktop, ensure sidebar is open by default
        setSidebarOpen(true);
      } else { // If resizing to mobile, ensure sidebar is closed by default
        setSidebarOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize(); // Initial check
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (isMobile && sidebarOpen) {
      setSidebarOpen(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location, isMobile]);


  return (
    <div className="flex h-screen bg-background text-text-primary overflow-hidden">
      <Sidebar 
        navItems={ADMIN_NAV_ITEMS} 
        appName={APP_NAME} 
        isOpen={sidebarOpen} 
        setIsOpen={setSidebarOpen} 
        isMobile={isMobile}
      />
      <div className={`flex-1 flex flex-col transition-all duration-300 ease-in-out ${sidebarOpen && !isMobile ? 'md:ml-64' : 'ml-0'}`}>
        <Navbar 
          userProfile={userProfile}
          userMenuItems={USER_MENU_ITEMS}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} 
          appName={APP_NAME}
          sidebarOpen={sidebarOpen}
        />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto bg-background">
          <div className="animate-fade-in">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
