
import React, { useState, useEffect } from 'react';
import { DashboardStat } from '../types';

// Simple count-up hook (can be moved to a separate file if preferred)
const useCountUp = (endValue: number, duration: number = 1500): number => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (typeof endValue !== 'number') {
      setCount(0); // Or some other default/error state
      return;
    }
    let startTime: number | undefined;
    let animationFrameId: number;

    const animate = (timestamp: number) => {
      if (startTime === undefined) {
        startTime = timestamp;
      }
      const progress = timestamp - startTime;
      const currentVal = Math.min(endValue, Math.floor((progress / duration) * endValue));
      
      setCount(currentVal);

      if (progress < duration) {
        animationFrameId = requestAnimationFrame(animate);
      } else {
        setCount(endValue); // Ensure it ends exactly on the endValue
      }
    };

    animationFrameId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [endValue, duration]);

  return count;
};


const SkeletonLoader: React.FC = () => (
  <div className="bg-background-surface p-6 rounded-2xl shadow-soft-lg animate-pulse">
    <div className="flex items-center justify-between mb-3">
      <div className="h-5 w-2/4 bg-background-muted rounded"></div>
      <div className="h-8 w-8 bg-background-muted rounded-full"></div>
    </div>
    <div className="h-10 w-1/3 bg-background-muted rounded mb-2"></div>
    <div className="h-4 w-1/4 bg-background-muted rounded"></div>
  </div>
);


const DashboardCard: React.FC<DashboardStat> = ({ title, value, icon: Icon, trend, loading }) => {
  const displayValue = typeof value === 'number' ? useCountUp(value) : value;

  if (loading) {
    return <SkeletonLoader />;
  }
  
  const isPositiveTrend = trend && trend.startsWith('+');
  const isNegativeTrend = trend && trend.startsWith('-');

  return (
    <div className="bg-background-surface p-6 rounded-2xl shadow-soft-lg transition-all duration-300 hover:shadow-soft-xl hover:scale-[1.02]">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-text-muted uppercase tracking-wider">{title}</h3>
        <div className="p-2 bg-brand-primary/10 rounded-full">
          <Icon className="w-6 h-6 text-brand-primary" />
        </div>
      </div>
      <p className="text-4xl font-serif font-bold text-text-primary mb-1">
        {typeof value === 'number' ? displayValue : value}
      </p>
      {trend && (
        <p className={`text-sm font-medium ${isPositiveTrend ? 'text-green-400' : isNegativeTrend ? 'text-red-400' : 'text-text-muted'}`}>
          {trend}
        </p>
      )}
    </div>
  );
};

export default DashboardCard;
