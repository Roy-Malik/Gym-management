
import React, { useState, useRef, useEffect } from 'react';
import { NavItem, UserProfile } from '../types';
import { MenuIcon } from './icons/MenuIcon';
import { BellIcon } from './icons/BellIcon';
import { ChevronDownIcon } from './icons/ChevronDownIcon';

interface NavbarProps {
  userProfile: UserProfile;
  userMenuItems: NavItem[];
  onToggleSidebar: () => void;
  appName: string;
  sidebarOpen: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ userProfile, userMenuItems, onToggleSidebar, appName, sidebarOpen }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [hasNewNotification, setHasNewNotification] = useState(true); // Mock state
  const dropdownRef = useRef<HTMLDivElement>(null);
  const notificationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleNotificationClick = () => {
    setNotificationsOpen(!notificationsOpen);
    setHasNewNotification(false); // Mark as read on open
  };
  
  return (
    <header className="sticky top-0 z-20 bg-background-surface shadow-soft-lg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left side: Hamburger menu and App Name (visible on mobile or when sidebar is closed) */}
          <div className="flex items-center">
            <button
              onClick={onToggleSidebar}
              className="p-2 rounded-md text-text-muted hover:text-text-primary hover:bg-background-muted focus:outline-none focus:ring-2 focus:ring-inset focus:ring-brand-primary"
              aria-label="Toggle sidebar"
            >
              <MenuIcon className="w-6 h-6" />
            </button>
            {(!sidebarOpen || window.innerWidth < 768) && (
                 <h1 className="ml-3 text-xl font-serif font-semibold text-brand-primary md:hidden">
                    {appName}
                </h1>
            )}
          </div>

          {/* Right side: Notifications and User Menu */}
          <div className="flex items-center space-x-4">
            {/* Notification Bell */}
            <div className="relative" ref={notificationRef}>
              <button 
                onClick={handleNotificationClick}
                className="p-2 rounded-full text-text-muted hover:text-text-primary hover:bg-background-muted relative"
                aria-label="Notifications"
              >
                <BellIcon className="w-6 h-6" />
                {hasNewNotification && (
                  <span className="absolute top-0 right-0 block h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-background-surface animate-pulse"></span>
                )}
              </button>
              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-background-surface rounded-lg shadow-soft-xl border border-border overflow-hidden animate-fade-in">
                  <div className="p-4 font-semibold text-text-primary border-b border-border">Notifications</div>
                  <div className="p-4 text-sm text-text-secondary">
                    {hasNewNotification ? "You have a new payment reminder." : "No new notifications."}
                  </div>
                   {/* Add more notifications here */}
                </div>
              )}
            </div>

            {/* User Dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center space-x-2 p-1 rounded-full hover:bg-background-muted transition-colors duration-200"
                aria-haspopup="true"
                aria-expanded={dropdownOpen}
              >
                <img
                  className="h-8 w-8 rounded-full object-cover border-2 border-brand-primary"
                  src={userProfile.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(userProfile.name)}&background=B08D57&color=fff`}
                  alt={userProfile.name}
                />
                <span className="hidden md:inline text-sm font-medium text-text-primary">{userProfile.name}</span>
                <ChevronDownIcon className={`hidden md:inline w-4 h-4 text-text-muted transition-transform duration-200 ${dropdownOpen ? 'rotate-180' : ''}`} />
              </button>
              {dropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-background-surface rounded-lg shadow-soft-xl border border-border overflow-hidden animate-fade-in">
                  <div className="py-2">
                    <div className="px-4 py-2 border-b border-border">
                      <p className="text-sm font-medium text-text-primary">{userProfile.name}</p>
                      <p className="text-xs text-text-muted">{userProfile.role}</p>
                    </div>
                    {userMenuItems.map((item) => (
                      <a
                        key={item.name}
                        href={`#${item.path}`} // Use hash for HashRouter compatibility
                        onClick={() => {
                          if (item.disabled) return;
                          setDropdownOpen(false);
                        }}
                        className={`block px-4 py-2 text-sm ${
                          item.disabled 
                            ? 'text-text-muted cursor-not-allowed' 
                            : 'text-text-secondary hover:bg-background-muted hover:text-text-primary'
                        } transition-colors duration-150`}
                        aria-disabled={item.disabled}
                      >
                        <item.icon className="inline w-4 h-4 mr-2" />
                        {item.name}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
