
import React from 'react';
import { NavLink } from 'react-router-dom';
import { NavItem } from '../types';
import { XIcon } from './icons/XIcon'; // Specific close icon

interface SidebarProps {
  navItems: NavItem[];
  appName: string;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  isMobile: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ navItems, appName, isOpen, setIsOpen, isMobile }) => {
  const baseItemClass = "flex items-center px-4 py-3 text-text-secondary hover:bg-background-muted hover:text-text-primary transition-colors duration-200 rounded-lg";
  const activeItemClass = "bg-brand-primary text-white shadow-md hover:bg-brand-hover";

  return (
    <>
      {/* Overlay for mobile */}
      {isMobile && isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity duration-300 ease-in-out"
          onClick={() => setIsOpen(false)}
        ></div>
      )}

      <aside 
        className={`fixed top-0 left-0 z-40 w-64 h-full bg-background-surface shadow-soft-lg flex flex-col transition-transform duration-300 ease-in-out
                   ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="flex items-center justify-between px-6 py-5 border-b border-border">
          <h1 className="text-2xl font-serif font-semibold text-brand-primary">{appName}</h1>
          {isMobile && (
            <button onClick={() => setIsOpen(false)} className="text-text-muted hover:text-text-primary">
              <XIcon className="w-6 h-6" />
            </button>
          )}
        </div>
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              end={item.path === "/"} // `end` prop for exact match on root path
              className={({ isActive }) => 
                `${baseItemClass} ${isActive ? activeItemClass : ''} ${item.disabled ? 'opacity-50 cursor-not-allowed' : ''}`
              }
              onClick={item.disabled ? (e) => e.preventDefault() : undefined}
              aria-disabled={item.disabled}
            >
              <item.icon className="w-5 h-5 mr-3 flex-shrink-0" />
              <span className="text-sm font-medium">{item.name}</span>
            </NavLink>
          ))}
        </nav>
        <div className="p-4 mt-auto border-t border-border">
          <p className="text-xs text-text-muted text-center">&copy; {new Date().getFullYear()} {appName}</p>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
