
import React from 'react';
import { NavItem } from './types';
import { HomeIcon, UsersIcon, ClipboardListIcon, CalendarDaysIcon, CreditCardIcon, BellIcon as AnnouncementBellIcon, SettingsIcon, LogOutIcon } from './components/icons';

export const ADMIN_NAV_ITEMS: NavItem[] = [
  { name: "Dashboard", path: "/", icon: HomeIcon },
  { name: "Members", path: "/members", icon: UsersIcon },
  { name: "Trainers", path: "/trainers", icon: UsersIcon },
  { name: "Workout Plans", path: "/workout-plans", icon: ClipboardListIcon },
  { name: "Diet Plans", path: "/diet-plans", icon: ClipboardListIcon },
  { name: "Schedule", path: "/schedule", icon: CalendarDaysIcon },
  { name: "Payments", path: "/payments", icon: CreditCardIcon },
  { name: "Announcements", path: "/announcements", icon: AnnouncementBellIcon },
];

export const USER_MENU_ITEMS: NavItem[] = [
    { name: "Profile", path: "/profile", icon: SettingsIcon, disabled: true }, // Example, not implemented
    { name: "Settings", path: "/settings", icon: SettingsIcon, disabled: true }, // Example, not implemented
    { name: "Logout", path: "/logout", icon: LogOutIcon, disabled: true }, // Example, not implemented
];

export const APP_NAME = "GymFlow Elite";
