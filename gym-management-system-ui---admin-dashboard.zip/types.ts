
import React from 'react';

export interface NavItem {
  name: string;
  path: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
  disabled?: boolean;
}

export interface UserProfile {
  name: string;
  role: string;
  avatarUrl?: string;
}

export interface DashboardStat {
  title: string;
  value: number | string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
  trend?: string; // e.g., "+5%"
  loading?: boolean;
}

export interface ChartDataPoint {
  name: string;
  value: number;
}

export interface RevenueData {
  month: string;
  revenue: number;
}
